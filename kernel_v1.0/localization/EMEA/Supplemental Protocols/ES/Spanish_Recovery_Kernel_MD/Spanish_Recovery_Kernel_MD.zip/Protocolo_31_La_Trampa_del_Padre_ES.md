
# EL NÚCLEO DE RECUPERACIÓN

*Módulos de Parche Suplementarios 01-36*
━━━━━━━━━━━━━━━━━━━━━━━━━━━

# PROTOCOLO 31

━━━━━━━━━━━━━━━━━━━━━━━━━━━

# LA TRAMPA DEL PADRE

*Cambiando el Motor en Plena Marcha / Protocolo de Desintoxicación en Casa para Cuidadores Primarios*

| 🔧 BITÁCORA DEL ARQUITECTO Llega la llamada: "Estoy bebiendo 15 unidades al día. Necesito ayuda." El centro de rehabilitación dice: "Tenemos una cama disponible. Es un programa de internación de 28 días." El padre/madre dice: "Tengo una hija de 11 años. Soy madre soltera. No hay nadie que la cuide por un mes." El centro de rehabilitación dice: "Lo siento, ese es el programa que ofrecemos." Click. Y ahora el padre/madre está solo/a. Con un hijo/a que criar. Con un cuerpo que grita por alcohol. Sin supervisión médica. Con nada más que pura fuerza de voluntad y "tomar mucha agua." Esta es LA TRAMPA DEL PADRE. El sistema de tratamiento dice: "28 días o nada." El padre/madre escucha: "Abandona a tu hijo/a o sufre solo/a." Así que sufren solos. Mientras siguen preparando almuerzos para la escuela. Mientras siguen revisando la tarea. Mientras siguen llevando a la práctica de fútbol. Mientras sus piernas no dejan de moverse a las 3 AM. Mientras su piel se arrastra y sus manos tiemblan. Este protocolo es para ELLOS. Para el padre/madre que no puede dejar de ser padre/madre. Para el cuidador que no tiene cuidadores de respaldo. Para el ser humano al que le dijeron "ve a rehabilitación" cuando "ve a rehabilitación" significa "abandona a tu hijo/a." No estás siendo tacaño/a. No estás siendo terco/a. No estás siendo irresponsable. Estás haciendo lo imposible: CAMBIANDO EL MOTOR EN PLENA MARCHA. Porque hay un niño/a en el asiento trasero. Y no puedes detenerte. Este protocolo es tu equipo de boxes. Vamos a sacarte de esto. — El Arquitecto de Sistemas |
| --- |


## Sección 31.1: VALIDANDO LO LOGÍSTICAMENTE IMPOSIBLE

*Por Qué 'Ve a Rehabilitación' No Es una Solución*

| 🛑 FALLO CRÍTICO DEL SISTEMA — EL BLOQUEO DE 28 DÍAS LA SUPOSICIÓN DEL SISTEMA: "Si realmente quisieras mejorar, irías a rehabilitación." LA REALIDAD: — Rehabilitación requiere 28 días fuera de casa — El cuidador primario no tiene a nadie que cuide al niño/a — El cuidado temporal no es una opción (y no debería serlo) — La familia está ausente, no disponible, o es insegura — El empleador no guardará el trabajo por un mes — El arrendador no esperará por la renta — El niño/a NECESITA a su padre/madre LA CONCLUSIÓN LÓGICA: Para un cuidador primario sin respaldo: "Ve a rehabilitación" = "Abandona a tu hijo/a" "No vayas a rehabilitación" = "Sufre sin apoyo médico" AMBAS OPCIONES SON INACEPTABLES. El sistema ha creado un binario falso. No se le ofrece al padre/madre una tercera opción. Así que CREAN la tercera opción: "Me desintoxicaré en casa, mientras cuido a mi hijo/a, sin ayuda." Esto no es irresponsabilidad. Esto es DEBER PARENTAL traducido a logística imposible. |
| --- |


| ✅ SISTEMA ESTABLE — ESTO ES CORAJE, NO FRACASO LO QUE LES DICEN: "No te tomas en serio la recuperación." "Estás poniendo excusas." "Si realmente amaras a tu hijo/a, buscarías ayuda." (La ironía más cruel: Su amor por su hijo/a ES la razón por la que no pueden ir.) LO QUE REALMENTE ESTÁ PASANDO: — SÍ se toman en serio la recuperación — SÍ están buscando ayuda (llamaron) — Aman a su hijo/a DEMASIADO para abandonarlo/a — Están eligiendo sufrir la abstinencia MIENTRAS mantienen responsabilidades parentales — Esto es MÁS DIFÍCIL que internarse, no más fácil EL REENCUADRE: No estás eligiendo el "camino fácil." Estás eligiendo el ÚNICO camino disponible para ti. Internarse sería MÁS FÁCIL: — Supervisión médica — Sin responsabilidades — Comidas preparadas para ti — Sin niño/a que cuidar — Enfoque completo en ti mismo/a Desintoxicación en casa mientras se cría es BRUTAL: — Sin supervisión médica — Todas las responsabilidades permanecen — Aún tienes que preparar comidas (para ellos) — El niño/a aún te necesita — Cero enfoque en ti mismo/a No estás siendo tacaño/a. Estás siendo UN PADRE/MADRE. No estás siendo terco/a. Estás siendo PRESENTE. No estás evitando la recuperación. La estás intentando bajo condiciones que la industria del tratamiento ignora. |
| --- |


| 🔧 BITÁCORA DEL ARQUITECTO Al padre/madre en La Trampa del Padre: El sistema te falló. No al revés. Una industria de tratamiento que solo ofrece "abandona a tu hijo/a por un mes" no ha ofrecido tratamiento a los padres. Ha ofrecido un ultimátum. Llamaste por ayuda. Dijeron "28 días." Dijiste "Tengo un hijo/a." Dijeron "Ese es el programa." Y ahora estás aguantando con los puños apretados durante la abstinencia mientras empacas almuerzos para la escuela. Eso no es debilidad. Eso es FORTALEZA. Eso no es irresponsabilidad. Eso es SACRIFICIO. Eso no son medias tintas. Eso es TODO LO QUE TIENES. Este protocolo existe porque tú existes. Porque los padres con adicciones existen. Porque los niños que necesitan a sus padres existen. Porque "28 días o nada" no es aceptable. Mereces apoyo. Vamos a construirlo. |
| --- |


## Sección 31.2: CRIANZA MÍNIMA VIABLE (CMV)

*Bajando la Barra a Altura Sobrevivible*

| 🛑 FALLO CRÍTICO DEL SISTEMA — EL COLAPSO DE ANCHO DE BANDA LA REALIDAD DE LA ABSTINENCIA: Durante la abstinencia aguda (Días 1-5), tu sistema experimentará: — Malestar físico severo (sudoración, temblores, náusea) — Fatiga extrema Y incapacidad para dormir — Deterioro cognitivo ("niebla mental," confusión) — Desregulación emocional (rabia, lágrimas, desesperación) — Dolor (dolores corporales, piernas inquietas, dolores de cabeza) — Capacidad reducida de toma de decisiones ESTO ES UN COLAPSO DE ANCHO DE BANDA. Tu poder de procesamiento total disponible caerá a 20-30%. Pero el niño/a aún necesita: — Ser alimentado/a — Estar seguro/a — Llegar a la escuela — Saber que es amado/a — No estar asustado/a por tu condición NO PUEDES HACER TODO. Si intentas mantener estándares normales: — Casa limpia — Comidas caseras — Ayuda con la tarea — Tiempo de calidad — Tu desempeño habitual de crianza ...FALLARÁS en todos ellos Y fallarás en la desintoxicación. LA SOLUCIÓN: MODO CMV. Crianza Mínima Viable. Lo absolutamente esencial. Nada más. Sobrevive primero. Optimiza después. |
| --- |


| ✅ SISTEMA ESTABLE — SI TODOS ESTÁN ALIMENTADOS Y SEGUROS, ESTÁS GANANDO LA REGLA CMV: Durante los Días 1-5, el éxito se mide por UNA métrica: "¿Está el niño/a ALIMENTADO/A y SEGURO/A?" Si sí: Estás teniendo éxito. Si sí Y nada más: SIGUES teniendo éxito. LA LISTA CMV (Diaria): □ El niño/a ha comido (cualquier cosa — estándares suspendidos) □ El niño/a está físicamente seguro/a □ El niño/a llegó a la escuela (o tiene supervisión si está en casa) □ El niño/a sabe que lo/a amas (una oración es suficiente) □ El niño/a no está asustado/a por la situación ESO ES TODO. Ese es el trabajo COMPLETO para los Días 1-5. Todo lo demás está SUSPENDIDO: — Limpieza: SUSPENDIDA (el desorden esperará) — Cocinar: SUSPENDIDO (ver Logística Desechable) — Ayuda con tarea: SUSPENDIDA (envía email al maestro si es necesario) — Actividades de calidad: SUSPENDIDAS (tiempo de pantalla autorizado) — Tu apariencia: SUSPENDIDA (pants son el uniforme) — Obligaciones sociales: SUSPENDIDAS (estás "enfermo/a") EL LENGUAJE PARA EL NIÑO/A: Explicación apropiada para la edad: "Mamá/Papá no se siente bien. Es como una gripe muy fuerte. Puede que no pueda hacer tanto los próximos días. Pero me estoy mejorando, y te amo. Estás siendo de mucha ayuda y estoy muy orgulloso/a de ti." NO HAGAS: — Sobre-explicar (no necesitan detalles) — Cargarlos con tu recuperación (no es su trabajo) — Hacerlos tu cuidador (TÚ sigues siendo el padre/madre) — Asustarlos con detalles médicos SÍ HAZ: — Tranquilizarlos de que estás bien (aunque no lo sientas) — Agradecerles por ser pacientes — Mantener estructura básica (hora de dormir, comidas, escuela) |
| --- |


| ✅ SISTEMA ESTABLE — SISTEMAS TÁCTICOS DE SUPERVIVENCIA No puedes cocinar. No puedes limpiar. Apenas puedes pararte. Pre-organiza estos sistemas ANTES del Día 1: LOGÍSTICA DE COMIDA: □ Platos de papel, utensilios de plástico (sin platos que lavar) □ Comidas congeladas pre-hechas (solo microondas) □ Apps de delivery cargadas y listas (pizza, supermercado) □ Cereal, leche, fruta (niño/a puede servirse solo/a el desayuno) □ Ingredientes para sándwich (niño/a puede hacer almuerzo si tiene edad) □ Barras de proteína, galletas, snacks fáciles en todos lados □ Efectivo o tarjeta con pareja para pedidos de comida LA REGLA: Nadie cocina. Todos comen. Estándares suspendidos. LOGÍSTICA ESCOLAR: □ Pre-empacar mochila la noche antes del Día 1 □ Poner múltiples alarmas para la rutina matutina □ Organizar transporte de respaldo (amigo, vecino, carpool) □ Email al maestro con anticipación: "Estoy lidiando con un problema de salud esta semana" □ Aceptar que la tarea puede no hacerse por unos días □ Plan de recogida: ¿Quién los recoge si no puedes manejar? LOGÍSTICA DE ENTRETENIMIENTO: □ Límites de tiempo de pantalla: SUSPENDIDOS para Días 1-5 □ Cargar tablet/TV con contenido aprobado □ "Puedes ver/jugar todo lo que quieras esta semana" □ Esto es supervivencia, no fracaso de crianza □ El tiempo de pantalla no los dañará; tu supervivencia importa más CONTACTOS DE EMERGENCIA: □ Adulto de confianza que pueda tomar al niño/a si la crisis escala □ Pareja/familiar en espera □ Teléfono cargado, contactos listos □ Saber cuándo llamar por ayuda médica (convulsión, síntomas severos) |
| --- |


| ÁREA DE CRIANZA | ESTÁNDAR NORMAL | ESTÁNDAR CMV (DÍAS 1-5) | POR QUÉ |
| --- | --- | --- | --- |
| Comidas | Caseras, balanceadas | Cualquier comida, cualquier fuente | No puedes cocinar ahora |
| Limpieza | Casa ordenada | Ignorar completamente | Esperará; tú no |
| Tarea | Supervisada, completada | Mejor esfuerzo o saltar | El maestro entenderá |
| Tiempo pantalla | Horas limitadas | Ilimitado temporalmente | Necesitas que estén ocupados y seguros |
| Hora de dormir | Rutina con cuentos | Llevarlos a la cama de alguna forma | Dormir importa; el ritual puede esperar |
| Tiempo de calidad | Actividades diarias | Presencia breve, amor verbal | Sobrevivir ES estar presente |
| Tu apariencia | Presentable | Pants, sin ducha si es necesario | Nadie te está calificando |
| Eventos sociales | Según programado | Cancelar todo | Estás "enfermo/a" |


## Sección 31.3: EL ROL DEL SERVIDOR PROXY

*Cómo la Pareja se Convierte en el Cortafuegos*

| 🔧 BITÁCORA DEL ARQUITECTO Del testimonio: "Le di todo mi dinero y tarjetas a los de afuera." Esta es una arquitectura de sistema BRILLANTE. El padre/madre reconoció su propio estado comprometido. Crearon un ESPACIO DE AIRE — una desconexión deliberada entre ellos mismos y la cadena de suministro. Sin dinero = Sin capacidad de comprar la sustancia. Sin tarjetas = Sin acceso impulsivo. Sin llaves = Sin capacidad de manejar para conseguirla. Convirtieron a su pareja en un SERVIDOR PROXY. Todo acceso al mundo exterior pasa por el proxy. El proxy filtra solicitudes. El proxy niega tráfico peligroso. Esto no es "ser cuidado como un bebé." Esto es GESTIÓN DE AMBIENTE CLÍNICO. La pareja no es un carcelero. La pareja es el CORTAFUEGOS. Y el cortafuegos debe entender su rol. |
| --- |


| ✅ SISTEMA ESTABLE — DESCONECTANDO DE LA CADENA DE SUMINISTRO EL CONCEPTO: En ciberseguridad, un "espacio de aire" es una separación física entre un sistema seguro y redes externas. Sin conexión = Sin vector de ataque. EL ESPACIO DE AIRE DEL PADRE/MADRE: Separación física del acceso a la sustancia. Si NO PUEDES conseguirla, el antojo se vuelve sobrevivible. Si PUEDES conseguirla, el antojo eventualmente ganará. QUÉ ENTREGAR (Antes del Día 1): □ Todo el efectivo (incluso monedas, incluso escondites) □ Todas las tarjetas (débito, crédito, de valor almacenado) □ Llaves del auto (si la sustancia es accesible manejando) □ Apps de compra del teléfono (eliminar, o dar teléfono a pareja) □ Acceso a Venmo/PayPal/CashApp (cerrar sesión, cambiar contraseña) □ Cualquier sustancia almacenada (obvio, pero crítico) □ Parafernalia (los disparadores son reales) QUIÉN LO GUARDA: □ Pareja/novio/a (si es confiable y presente) □ Familiar de confianza □ Amigo/a de confianza (que entienda las consecuencias) □ NO escondido en la casa (lo encontrarás) □ NO en algún lugar donde puedas convencer que te lo den LA REGLA DEL DINERO: Debes tener acceso a CERO dinero discrecional durante los Días 1-5. Si el niño/a necesita algo: La pareja compra. Si tú necesitas algo: La pareja compra. Si hay una emergencia: La pareja lo maneja. Estás voluntariamente en un "cuarto limpio financiero." Esto no es humillación. Esto es PROTECCIÓN. Te estás protegiendo DE ti mismo/a durante la ventana en que tu toma de decisiones está comprometida. |
| --- |


| ✅ SISTEMA ESTABLE — ENTRENANDO AL CORTAFUEGOS LA IDEA EQUIVOCADA DE LA PAREJA: "Estoy cuidando a un adicto como si fuera un bebé." LA REALIDAD: "Estoy gestionando el ambiente clínico para una desintoxicación médica." PUNTOS DE BRIEFING PARA LA PAREJA: 1. ESTO ES UN EVENTO MÉDICO — La abstinencia no es una elección; es fisiología — Los síntomas son reales, no drama — La irritabilidad es química, no carácter — Están enfermos, no son malos 2. TU TRABAJO ES CORTAFUEGOS, NO CARCELERO — Guardas los recursos para prevenir acceso impulsivo — No los estás castigando; los estás protegiendo — Ellos TE PIDIERON hacer esto; estás honrando su solicitud — Cuando el antojo golpee, pueden rogar, negociar, enfurecerse — Tu trabajo: Mantener la línea SIN juzgar 3. EL NIÑO/A ES CO-PRIORIDAD — Puede que necesites asumir el rol de cuidador primario temporalmente — Escuela, comidas, supervisión pueden caer en ti — Esto es Días 1-5, no para siempre — El padre/madre está luchando por REGRESAR, no rindiéndose 4. LO QUE VERÁS: — Síntomas físicos (sudoración, temblores, vómito) — Cambios de humor (llanto, enojo, desesperación) — Solicitudes irracionales ("Solo déjame tener UNO") — Interrupción del sueño (tuya y de ellos) — Una pareja que no parece tu pareja 5. QUÉ HACER: — Mantén la línea en dinero/llaves/acceso — Provee apoyo práctico (agua, comida, cobijas) — Recuérdales que esto es temporal — No te involucres con negociaciones — solo repite: "Te amo. No." — Monitorea señales de peligro (convulsiones, síntomas extremos) — Cuídate A TI MISMO/A también 6. QUÉ NO HACER: — No sermonees ni moralices — No digas "Te lo dije" — No expreses disgusto — No los dejes completamente solos por períodos largos — No cedas "solo esta vez" — No tomes la rabia personalmente |
| --- |


| ROL DE PAREJA | FUNCIÓN | ACCIONES CRÍTICAS | ERRORES COMUNES |
| --- | --- | --- | --- |
| Cortafuegos Financiero | Bloquear acceso a dinero | Guardar todo efectivo/tarjetas, controlar compras | Ceder a solicitudes de "solo $20" |
| Bloqueo de Transporte | Prevenir idas por suministro | Guardar llaves del auto, no llevarlos a acceso | Dejarlos "solo ir a manejar" |
| Apoyo al Niño/a | Cubrir brechas de crianza | Escuela, comidas, supervisión | Esperar que padre/madre funcione normalmente |
| Ancla Emocional | Proveer estabilidad | "Te amo. Esto es temporal." | Tomar irritabilidad personalmente |
| Monitor Médico | Vigilar señales de peligro | Conocer signos de convulsión, cuándo llamar 911 | Ignorar síntomas severos |
| Control de Ambiente | Mantener cuarto limpio | Sin sustancias en casa, sin visitantes facilitadores | Invitar amigos "útiles" que traen suministros |


## Sección 31.4: APOYO BIOLÓGICO PARA EL CAMBIO EN MARCHA

*Estabilizadores del Sistema para Abstinencia de Opioides/GABA*

| 🛑 FALLO CRÍTICO DEL SISTEMA — 'TOMAR MUCHA AGUA' NO ES SUFICIENTE EL TESTIMONIO: "Solo tomaré mucha agua y lo superaré." EL PROBLEMA: El agua es necesaria pero INSUFICIENTE. La abstinencia de opioides y GABA involucra: — Depleción de electrolitos (sudoración, vómito, diarrea) — Colapso de magnesio (piernas inquietas, calambres, ansiedad) — Desregulación de receptores opioides (amplificación del dolor) — Depleción de neurotransmisores (colapsos de humor) — Oleada de cortisol (ansiedad, inflamación) — Colapso de arquitectura del sueño (insomnio, descanso fragmentado) El agua reemplaza AGUA. No reemplaza electrolitos. No calma receptores. No aborda la neuroquímica. EL RESULTADO DEL ENFOQUE SOLO-AGUA: — Electrolitos diluidos (riesgo de hiponatremia) — Piernas inquietas continuas (magnesio no reemplazado) — Dolor no manejado (receptores aún gritando) — Irritabilidad extrema (afectando al niño/a) — Abstinencia más larga, más difícil, más peligrosa LA SOLUCIÓN: Necesitamos ESTABILIZADORES DEL SISTEMA. Apoyo químico que reduce severidad de síntomas y protege la relación padre-hijo de la rabia/irritabilidad de abstinencia no manejada. |
| --- |


| ✅ SISTEMA ESTABLE — APOYO QUÍMICO PARA DESINTOXICACIÓN EN CASA ARMA ESTO ANTES DEL DÍA 1: NIVEL 1: HIDRATACIÓN + ELECTROLITOS □ Solución de electrolitos (Liquid IV, LMNT, Pedialyte) — NO solo agua — 3-4 porciones diarias mínimo — Reemplaza lo que sudoración/vómito depletan □ Agua de coco (electrolitos naturales) □ Caldo de huesos (sodio, minerales, fácil para el estómago) POR QUÉ: Agua pura diluye electrolitos restantes. Solución de electrolitos los REEMPLAZA. NIVEL 2: MAGNESIO (Crítico para Piernas Inquietas/Ansiedad) □ Glicinato de Magnesio: 400-800mg al acostarse — Forma glicinato es calmante, bien absorbida — Aborda piernas inquietas directamente — Reduce ansiedad, apoya sueño — Puede tomar 200mg adicional si piernas inquietas severas □ Alternativa: Treonato de Magnesio (cruza barrera hematoencefálica) □ Baños de sales de Epsom (magnesio absorbido por piel + calmante) POR QUÉ: Piernas inquietas es frecuentemente DEFICIENCIA DE MAGNESIO agudizada por abstinencia. NIVEL 3: PROTOCOLO DE VITAMINA C (Para Receptores Opioides) □ Vitamina C en dosis alta: 2-4 gramos cada 2-3 horas — Forma ascorbato de sodio o liposomal preferida — Reduce severidad de abstinencia opioide significativamente — Investigación apoya modulación de receptor mu-opioide — Tomar hasta tolerancia intestinal, luego reducir ligeramente — Puede causar heces sueltas en dosis altas (ese es el límite) POR QUÉ: Protocolo de Vitamina C tiene apoyo de investigación para reducir severidad. NIVEL 4: APOYO GABA □ L-Teanina: 200-400mg según necesidad — Calmante sin sedación, seguro, sin riesgo de dependencia □ Taurina: 1-2g diarios (apoya función GABA, calmante) □ Té o extracto de melisa (apoyo GABA suave) POR QUÉ: Alcohol/FeelFree/benzos afectan sistema GABA. Apoyar GABA naturalmente facilita transición. NIVEL 5: APOYO PARA DORMIR □ Melatonina: 0.5-3mg al acostarse (empezar bajo, aumentar si necesario) □ Magnesio (ya listado, pero clave para sueño) □ Té de manzanilla □ EVITAR: Benadryl (puede empeorar piernas inquietas), alcohol (obviamente) NIVEL 6: ARTÍCULOS DE CONFORT □ Almohadilla térmica (para dolores corporales) □ Cobija con peso (puede ayudar piernas inquietas, provee confort) □ Cobijas extra (regulación de temperatura alterada) □ Cubeta junto a la cama (náusea) □ Galletas/pan tostado (suave para el estómago) □ Té o caramelos de jengibre (anti-náusea) |
| --- |


| SÍNTOMA | ESTABILIZADOR PRINCIPAL | DOSIS/APLICACIÓN | POR QUÉ FUNCIONA |
| --- | --- | --- | --- |
| Piernas inquietas | Glicinato de Magnesio | 400-800mg, puede repetir | Piernas inquietas frecuentemente relacionado con magnesio; calma nervios |
| Dolores corporales | Vitamina C dosis alta | 2-4g cada 2-3 horas | Modula receptores opioides, antiinflamatorio |
| Ansiedad/agitación | L-Teanina | 200-400mg según necesidad | Promueve calma sin sedación |
| Deshidratación | Solución electrolitos | 3-4 porciones diarias | Reemplaza minerales perdidos, previene hiponatremia |
| Insomnio | Magnesio + Melatonina | Mag en noche, Mel 0.5-3mg | Apoya arquitectura del sueño |
| Náusea | Jengibre + sorbos pequeños | Té, caramelos, sorbos frecuentes | Calma estómago, previene deshidratación |
| Irritabilidad/rabia | Todo lo anterior + tiempo | Reducir síntomas reduce irritabilidad | Confort ↑ = Paciencia ↑ = Niño/a protegido/a |


| ⚠️ PRECAUCIÓN DEL SISTEMA — POR QUÉ EL APOYO BIOLÓGICO IMPORTA PARA EL NIÑO/A EL RIESGO OCULTO: Abstinencia no manejada causa irritabilidad extrema. Irritabilidad + necesidades del niño/a = Zona de peligro. ESCENARIO SIN APOYO: — Padre/madre en malestar severo (piernas inquietas, sudores, dolor) — Niño/a hace una pregunta normal o hace ruido normal — Padre/madre EXPLOTA (rabia es un síntoma de abstinencia) — Niño/a está asustado/a — Padre/madre siente culpa, espiral de vergüenza se intensifica — Riesgo de decir/hacer cosas que dañen la relación — Riesgo de recaída para "solo hacer que pare" ESCENARIO CON APOYO: — Padre/madre en malestar pero algo manejado — Magnesio ha calmado las piernas inquietas — Vitamina C ha quitado el filo del dolor — L-Teanina ha reducido la agitación — Niño/a hace una pregunta normal — Padre/madre responde con esfuerzo pero sin explosión — "Perdón, Mami/Papi está cansado/a. Te amo. ¿Me das unos minutos?" — Niño/a está tranquilo/a — Relación preservada LA ECUACIÓN: Apoyo biológico → Severidad de síntomas reducida → Irritabilidad reducida → Paciencia preservada → Relación padre-hijo protegida → Reducción de culpa → Riesgo de recaída reducido Esto no es sobre confort por sí mismo. Es sobre PROTEGER AL NIÑO/A del daño colateral de abstinencia no manejada. Cada suplemento es un buffer entre tu dolor y su experiencia. |
| --- |


## Sección 31.5: LA GUÍA DE SUPERVIVENCIA DIARIA

*Operaciones Tácticas Hora por Hora*

| DÍA | ESTADO ESPERADO | CAPACIDAD DE CRIANZA | ENFOQUE PRINCIPAL |
| --- | --- | --- | --- |
| Día 1 | Síntomas comenzando, ansiedad alta | 50-60% — puede funcionar con esfuerzo | Configurar sistemas, briefing a pareja, último día normal |
| Día 2 | Síntomas intensificándose, sueño pobre | 30-40% — luchando significativamente | Modo CMV activo, pareja intensifica, supervivencia |
| Día 3 | Frecuentemente el PEOR día — pico de síntomas | 20-30% — capacidad mínima | Pura supervivencia, pantalla autorizada, pedir ayuda si necesario |
| Día 4 | Síntomas aún severos pero pueden estabilizarse | 30-40% — ligeramente mejor | Continuar CMV, no confiarse demasiado |
| Día 5 | Comenzando a mejorar para la mayoría | 40-50% — luz visible | Mantener protocolo, retorno gradual de capacidad |
| Días 6-7 | Mejora significativa típica | 60-70% — acercándose a función | Reanudar lentamente algunas actividades normales |
| Semana 2 | Síntomas físicos mayormente resueltos | 70-80% — casi normal | Apoyo emocional necesario, PAWS puede aparecer |


| ✅ SISTEMA ESTABLE — SACANDO AL NIÑO/A POR LA PUERTA (Rutina Matutina) EL DESAFÍO: Son las 6:30 AM. Dormiste 2 horas. Te duelen las piernas. El niño/a necesita llegar a la escuela. EL PROTOCOLO: NOCHE ANTERIOR (Cada noche Días 1-5): □ Ropa lista (del niño/a) □ Mochila empacada y junto a la puerta □ Almuerzo empacado O dinero para almuerzo en mochila □ Tu ropa lista (lo que sea que vayas a usar) □ Alarmas configuradas (múltiples, fuertes) □ Estabilizadores en mesita de noche (Mag, agua, Vitamina C) MAÑANA (Rutina mínima viable): 5:00-6:00 AM (Si estás despierto/a — probablemente lo estés): □ Toma magnesio, Vitamina C, electrolitos □ Baño, auto-cuidado mínimo □ Descansa hasta que el niño/a necesite despertar 6:00-6:30 AM (Despertar del niño/a): □ "Hora de levantarse, cariño" □ Señálales la ropa lista □ Se visten solos (si tienen edad) □ Puedes quedarte horizontal si es necesario 6:30-7:00 AM (Desayuno): □ Cereal + leche (auto-servicio si tienen edad) □ O: Pan tostado, fruta, cualquier cosa fácil □ Pareja maneja si está disponible □ Pantalla permitida durante desayuno (estándares suspendidos) 7:00-7:30 AM (Lanzamiento escolar): □ Mochila (ya empacada) □ Zapatos puestos □ Transporte: Pareja, carpool, vecino, bus □ Si tú manejas: NO manejes bajo efectos — Si no puedes manejar seguro, no manejes — Organiza respaldo AHORA antes del Día 1 □ Abrazo, "Te amo," salen por la puerta 7:30 AM — COLAPSO: □ Regresa a cama/sofá □ Estabilizadores, descanso, pantallas, supervivencia □ Lo lograste. Una mañana menos. |
| --- |


| ✅ SISTEMA ESTABLE — MANEJANDO LA TARDE/NOCHE EL DESAFÍO: El niño/a llega a casa. Necesita atención. Estás exhausto/a, irritable, con dolor. EL PROTOCOLO: 3:00-3:30 PM (Preparación pre-llegada): □ Toma L-Teanina (buffer de paciencia) □ Come algo, aunque no quieras □ Breve descanso si es posible □ Recuérdate: "1-2 horas de presencia, luego descanso" 3:30-4:00 PM (Llegada): □ Salúdalos cálidamente (finge si es necesario) □ "¿Cómo estuvo la escuela?" — escucha brevemente □ Snack (pre-organizado, fácil) □ Evalúa sus necesidades: ¿Necesitan a TI o pueden ocuparse solos? 4:00-6:00 PM (Tiempo puente): □ Si pueden auto-ocuparse: Pantalla, tarea (independiente), jugar □ Si necesitan presencia: Siéntate con ellos, actividades de mínimo esfuerzo — Ver un programa juntos (tú descansas, ellos contentos) — Juego de mesa simple si puedes manejarlo — Solo estar en el mismo cuarto cuenta □ Chequea periódicamente: "¿Todo bien? ¿Necesitas algo?" 6:00-7:00 PM (Cena): □ Delivery, comida congelada, pareja cocina □ Platos de papel □ Comer juntos si es posible (aunque apenas comas) □ Conexión breve: "¿Cuál fue la mejor parte de tu día?" 7:00-8:00 PM (Rutina de dormir): □ Dientes cepillados (no negociable) □ Pijamas puestos □ Arropada rápida (puede saltar cuento si es necesario) □ "Te amo. Estoy muy orgulloso/a de ti. Duerme bien." □ Luz encendida si la necesitan 8:00 PM — TU TIEMPO: □ Colapso □ Toma estabilizadores nocturnos □ Pareja toma monitoreo si está en casa □ Intenta descansar, sabiendo que la mañana viene |
| --- |


## Sección 31.6: CUÁNDO PEDIR AYUDA

*Líneas Rojas que Requieren Intervención Médica*

| 🛑 FALLO CRÍTICO DEL SISTEMA — LA ABSTINENCIA DE ALCOHOL PUEDE MATAR ADVERTENCIA CRÍTICA: La abstinencia de alcohol es MÉDICAMENTE PELIGROSA. A diferencia de la mayoría de las sustancias, la abstinencia de alcohol/benzos puede causar: — Convulsiones (potencialmente fatales) — Delirium tremens (DTs) — emergencia médica — Eventos cardíacos — Muerte SI ESTÁS EN ABSTINENCIA DE: — Alcohol diario pesado (15+ unidades/día) — Benzodiazepinas (Xanax, Valium, Klonopin) — Productos de kratom/FeelFree en dosis alta PUEDES NECESITAR SUPERVISIÓN MÉDICA. Este protocolo provee APOYO, no reemplazo de cuidado médico. CUÁNDO LLAMAR 911 O IR A URGENCIAS: □ Convulsión (cualquier actividad de convulsión) □ Confusión severa, alucinaciones, no saber dónde estás □ Palpitaciones cardíacas que no paran □ Fiebre sobre 38.3°C con confusión □ Temblores severos que no puedes controlar □ Vomitar sangre o sangre en heces □ Dolor de pecho □ Pensamientos de autolesión □ Sientes que te estás muriendo y no es ansiedad SI NO ESTÁS SEGURO/A: LLAMA. El niño/a te necesita VIVO/A. Una visita al hospital es mejor que la alternativa. OPCIONES DE APOYO AMBULATORIO: — Algunos doctores recetarán medicación para desintoxicación en casa — Reducción gradual de Librium (clordiazepóxido) para alcohol — Consultas de telesalud de medicina de adicciones — Pregunta: "¿Puedo hacer una desintoxicación ambulatoria con supervisión médica?" — Este es el CAMINO MEDIO entre "28 días" y "nada" PUEDES ABOGAR POR OPCIONES INTERMEDIAS. |
| --- |


| ✅ SISTEMA ESTABLE — EL PLAN DE RESPALDO ANTES DEL DÍA 1, ESTABLECE: RESPALDO MÉDICO: □ Nombre y número de doctor que conoce tu situación □ Dirección de urgencias más cercana (por si acaso) □ Pareja informada sobre cuándo llamar 911 □ Opción de telesalud identificada para preguntas RESPALDO PARA NIÑO/A: □ Persona que puede tomar al niño/a si necesitas urgencias □ Persona que puede venir a la casa en emergencia □ Bolsa de noche del niño/a empacada, por si acaso □ Escuela sabe que hay una "situación de salud familiar" EL PERMISO: Si necesitas ir al hospital: — ESO NO ES FRACASO — Eso es crianza responsable — Obtener ayuda médica es BUENO — El niño/a va al respaldo — Te estabilizan — Regresas a casa y continúas Ir a urgencias ≠ Abandonar al niño/a Ir a urgencias = Asegurar que sobrevives para el niño/a DATE ESTE PERMISO AHORA: "Si mi cuerpo necesita atención médica, la obtendré. Eso no es debilidad. Eso es supervivencia. La meta es estar aquí para mi hijo/a A LARGO PLAZO. Una noche en el hospital sirve a esa meta." |
| --- |


## Sección 31.7: PUNTOS CLAVE A RECORDAR


| ✅ SISTEMA ESTABLE — PROTOCOLO 31 — PUNTOS CLAVE 1. LA TRAMPA DEL PADRE ES UN FALLO DEL SISTEMA, NO TU FRACASO — "28 días o nada" no es tratamiento para padres — Es un ultimátum que ignora la realidad del cuidado — Elegir desintoxicación en casa no es irresponsabilidad — A menudo es la ÚNICA opción disponible 2. ESTÁS CAMBIANDO EL MOTOR EN PLENA MARCHA — No puedes dejar de criar durante la desintoxicación — Esto es más difícil que internarse, no más fácil — Estás haciendo lo imposible por amor — Eso es fortaleza, no debilidad 3. CRIANZA MÍNIMA VIABLE (CMV) — Días 1-5: "Alimentado y seguro" = éxito — Suspende todos los estándares no críticos — Tiempo de pantalla está autorizado — Platos de papel, delivery, modo supervivencia — Si todos están vivos al final, ganaste 4. LOGÍSTICA DESECHABLE — Pre-organiza todo antes del Día 1 — Comida: Congelada, delivery, auto-servicio — Escuela: Transporte de respaldo, maestro notificado — Entretenimiento: Pantallas ilimitadas temporalmente — Sin cocinar, sin limpiar, sin esfuerzo extra 5. EL ESPACIO DE AIRE / CORTAFUEGOS — Entrega dinero, tarjetas, llaves — Crea separación física de la cadena de suministro — La pareja es cortafuegos, no carcelero — La pareja mantiene la línea sin juzgar — Tú pediste esto; están honrando tu solicitud 6. BRIEFING DE LA PAREJA — Esto es médico, no moral — Gestionan ambiente clínico — Verán síntomas: No tomarlo personalmente — "Te amo. No." — Ese es todo el guión — Vigilar señales de peligro; saber cuándo llamar 911 7. ESTABILIZADORES DEL SISTEMA (No Solo Agua) — Electrolitos: 3-4 porciones diarias (no solo agua) — Magnesio: 400-800mg para piernas inquietas/ansiedad — Vitamina C: 2-4g cada 2-3 horas (apoyo opioide) — L-Teanina: 200-400mg para calma — Estos PROTEGEN tu relación con tu hijo/a 8. APOYO BIOLÓGICO = PROTECCIÓN DEL NIÑO/A — Síntomas manejados = Irritabilidad reducida — Irritabilidad reducida = Más paciencia — Más paciencia = Sin explosiones hacia el niño/a — Cada suplemento es un buffer entre tu dolor y ellos 9. SUPERVIVENCIA DIARIA — Noche anterior: Empacar todo — Mañana: Rutina mínima viable, llevarlos a escuela — Tarde: Presencia sin performance — Noche: Cena delivery, conexión breve, cama — Colapso después de las 8 PM 10. SABER CUÁNDO PEDIR AYUDA — Abstinencia de alcohol/benzos puede ser fatal — Convulsiones, DTs, síntomas severos = Urgencias — Ten plan de respaldo para el niño/a — Ir al hospital NO es fracaso — Es asegurar que sobrevives para ellos 11. LA EXPERIENCIA DEL NIÑO/A — Explicación apropiada para la edad: "Mami/Papi está enfermo/a" — Tranquilidad: "Me estoy mejorando, te amo" — No los cargues con detalles — No necesitan ser tu cuidador — Presencia breve cuenta; solo estar ahí 12. ESTO ES TEMPORAL — Días 1-5 son los peores — SÍ mejora — Semana 2 es significativamente más fácil — SÍ lo estás haciendo — Estás luchando por estar presente para ellos |
| --- |


| 🔧 BITÁCORA DEL ARQUITECTO — TRANSMISIÓN FINAL Nota Final del Sistema: Al padre/madre en el baño a las 3 AM, piernas arrastrándose, empapado/a en sudor, luchando por no manejar a la tienda, sabiendo que el/la niño/a de 11 años está dormido/a por el pasillo y tienes que ponerlo/a en el bus en 4 horas: Te veo. Estás haciendo la versión más difícil posible de esto. No la versión con personal médico y tres comidas al día y sin responsabilidades excepto tu propia sanación. La versión donde te estás sanando a ti mismo/a mientras sigues siendo el mundo entero de alguien. La versión donde estás cambiando el motor mientras el auto sigue en movimiento porque hay un niño/a en el asiento trasero y no puedes detenerte. No elegiste esta situación imposible. Pero estás eligiendo luchar a través de ella. Cada hora que no usas es una victoria. Cada mañana que los llevas a la escuela es un triunfo. Cada noche que los arropas es prueba de que el amor es más fuerte que la química. No eres el padre/madre que abandonó a su hijo/a. Eres el padre/madre que se aferró cuando soltar habría sido más fácil. Día a día. Hora a hora. Alimentado y seguro. Alimentado y seguro. Lo estás logrando. Sigue adelante. — El Arquitecto de Sistemas |
| --- |

━━━━━━━━━━━━━━━━━━━━━━━━━━━

# FIN DEL PROTOCOLO 31 — LA TRAMPA DEL PADRE
