# Placeholder for calling external ChatGPT/OpenAI for second opinion/explanation (keep PHI out unless under a BAA).
import os

def ask_chatgpt(prompt: str) -> str:
    # TODO: Implement via openai SDK if desired; ensure compliance before sending PHI
    return "(ChatGPT integration not enabled in starter)"